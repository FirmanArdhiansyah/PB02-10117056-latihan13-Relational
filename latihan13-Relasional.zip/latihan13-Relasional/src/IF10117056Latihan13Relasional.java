/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Firman Ardhiansyah
 */
public class IF10117056Latihan13Relasional {

    public static void main(String[] args) {
      int bill = 10;
      int bil2 = 20;
      System.out.println("a == b = " + (bill == bil2));
      System.out.println("a != b = " + (bill != bil2));
      System.out.println("a > b = " + (bill > bil2));
      System.out.println("a < b = " + (bill < bil2));
      System.out.println("b >= a = " + (bil2 >= bill));
      System.out.println("b <= a = " + (bil2 <= bill));
    
    }
    
}
